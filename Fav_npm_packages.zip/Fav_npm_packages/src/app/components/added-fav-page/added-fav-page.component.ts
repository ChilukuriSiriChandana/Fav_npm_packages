import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-added-fav-page',
  templateUrl: './added-fav-page.component.html',
  styleUrls: ['./added-fav-page.component.css']
})
export class AddedFavPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
